#include"linkedlist.h"

PLinkedList createLinkedList()
{
	PLinkedList	newList=(PLinkedList)malloc(sizeof(LinkedList));
	//��ʼ��
	newList->header = NULL;
	newList->ender = NULL;
	newList->size = 0;
	return newList;
}

PNode createNode(void* data)
{
	PNode newNode=(PNode)malloc(sizeof(Node));
	//�½ڵ��ʼ��
	newNode->prev = NULL;
	newNode->data = data;
	newNode->next = NULL;
	return newNode;
}

void add(PLinkedList list, void* data)
{
	PNode newnode=createNode(data);
	if ( list->size==0)//������
	{
		list->header = list->ender = newnode;
		list->size = 1;
	}
	else
	{
		list->ender->next = newnode;
		newnode->prev = list->ender;
		list->ender = newnode;
		list->size++;
	}
}

void insert(PLinkedList list, int index, void* data)
{
	//1 ��������ֱ��add׷�ӵ�β��
	// 	 3 ����㳬������±� Ӧ�÷ŵ����� ִ��add
	if ( list->size==0 || index>list->size-1 )
	{
		add(list, data);
		return;
	}
	PNode newnode = createNode(data);
	//2 index��0
	if ( index<=0)//���뵽ͷ��
	{
		newnode->next = list->header;
		list->header->prev = newnode;
		list->header = newnode;
	}
	else
	{
		//�м����
		PNode p = findNode(list, index);
		PNode q = p->prev;
		p->prev = newnode;
		newnode->next = p;
		q->next = newnode;
		newnode->prev = q;
	}
	list->size++;
}

void* removeIndex(PLinkedList list, int index)
{
	//1������
	if (list->size==0) {
		return NULL;
	}
	PNode p;//ָ�� ��ɾ���Ľڵ�
	//2 Ψһ�Ľڵ㱻ɾ��
	if (list->size==1)
	{
		p = list->header;
		list->header = NULL;
		list->ender = NULL;
	}
	//3ɾ��ͷ
	else if ( index<=0)
	{
		p = list->header;
		list->header = p->next;
		list->header->prev = NULL;
	}
	//4ɾ��β��
	else if (index>=list->size-1)
	{
		p = list->ender;
		list->ender = p->prev;
		list->ender->next = NULL;
	}
	//5�м�ɾ��
	else
	{
		p = findNode(list, index);
		PNode q = p->prev;
		PNode n = p->next;
		q->next = n;
		n->prev = q;
	}
	//��ɾ4����
	void* temp = p->data;
	free(p);
	list->size--;
	return temp;
}

void* get(PLinkedList list, int index)
{
	PNode p = findNode(list, index);
	return p!=NULL ? p->data :NULL ;
}

PNode findNode(PLinkedList list, int index)
{
	PNode p = list->header;
	for (int i=0 ;i<index &&index<list->size  ;i++ )
	{
		p = p->next;
	}
	return p;
}

int size(PLinkedList list)
{
	return list->size;//������Ա����
}

void clear(PLinkedList list)
{
	PNode p = list->header;
	PNode q = NULL;
	while ( p!=NULL)
	{
		q = p;
		p = p->next;
		free(q);
		list->size--;
	}
	list->header = list->ender = NULL;
}

void iterator(PLinkedList list)
{
	list->nextNode = list->header;
}

int hasNext(PLinkedList list)
{
	return list->nextNode!= NULL;
}

void* next(PLinkedList list)
{
	void* tmp = list->nextNode->data;
	//Ϊ��һ��ȡ������׼��
	list->nextNode = list->nextNode->next;
	return tmp;
}
