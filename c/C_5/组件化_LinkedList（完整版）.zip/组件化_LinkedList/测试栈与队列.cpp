#include<stdio.h>
#include"linkedlist.h"
int main3()
{
	//����ջLIFO��last in first out ����ȳ� */
	/*PLinkedList stack = createLinkedList();
	push(stack, "��");
	push(stack, "��");
	push(stack, "��");
	const char* str;
	str=(const char*)pop(stack);
	printf("%s\n",str);
	str = (const char*)pop(stack);
	printf("%s\n", str);
	str = (const char*)pop(stack);
	printf("%s\n", str);
	str = (const char*)pop(stack);
	printf("%s\n", str);*/
	/*ʵ�ֶ���queue�Ĺ��ܣ�FIFO��first in first out �Ƚ��ȳ� */
	PLinkedList queue = createLinkedList();
	addFirst(queue, "aa");
	addFirst(queue, "bb");
	addFirst(queue, "cc");
	addFirst(queue, "dd");
	const char* str;
	str =(const char*) removeLast(queue);
	printf("%s\n", str);
	str = (const char*)removeLast(queue);
	printf("%s\n", str);
	str = (const char*)removeLast(queue);
	printf("%s\n", str);
	str = (const char*)removeLast(queue);
	printf("%s\n", str);
	str = (const char*)removeLast(queue);
	printf("%s\n", str);
	return 0;
}