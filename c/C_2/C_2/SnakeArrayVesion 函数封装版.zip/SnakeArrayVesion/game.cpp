#include "game.h"

void gameover(void)
{
	extern int stop;
	stop = 1;
}
