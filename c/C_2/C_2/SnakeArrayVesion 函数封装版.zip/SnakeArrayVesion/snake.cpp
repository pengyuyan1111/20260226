#include "snake.h"
#include"apple.h"
int fangXiang = 1;//���� 0�� 1�� 2�� 3 ��
int snakeSize = 5;//�� ��ǰ�Ĵ�С
int snakeLie[100] = { 10,10,10,10,10 };
int snakeHang[100] = { 10,11,12,13,14 };

void snakeMove(void)
{
	//���嶯
	for (int j = snakeSize - 1;j >= 1;j--)
	{
		snakeHang[j] = snakeHang[j - 1];
		snakeLie[j] = snakeLie[j - 1];
	}
	//ͷ��
	switch (fangXiang)
	{
	case 0:
		snakeLie[0]++;
		break;
	case 1:
		snakeHang[0]--;
		break;
	case 2:
		snakeLie[0]--;
		break;
	case 3:
		snakeHang[0]++;
		break;
	}
}

void snakeGrow(void)
{
	snakeSize++;
}
int enabledEatApple(void)
{
	return  snakeHang[0] == appleHang
		&& snakeLie[0] == appleLie;
}
int enabledOut(void)
{
	return  snakeHang[0] == 0 || snakeHang[0] == 19
		|| snakeLie[0] == 0 || snakeLie[0] == 19;
}
int enabledEatSelf(void)
{
	//int neng = 0;//���� ����ҧ���Լ�
	for (int j=1  ; j<snakeSize; j++)
	{
		if (snakeHang[0] == snakeHang[j]
			&& snakeLie[0]==snakeLie[j]) 
		{
			//neng = 1;//�Ʒ�����
			//break;
			return 1;
		}
	}
	return 0;
}


/*��ת*/
void turnLeft(void)
{
	if (fangXiang != 0)
	{
		fangXiang = 2;
	}
}
/*��ת*/
void turnRight(void)
{
	if (fangXiang != 2)
	{
		fangXiang = 0;
	}
}
/*��ת*/
void turnUp(void)
{
	if (fangXiang != 3)
	{
		fangXiang = 1;
	}
}
/*��ת*/
void turnDown(void)
{
	if (fangXiang != 1)
	{
		fangXiang = 3;
	}
}

IMAGE imgHead [4];
IMAGE imgBody;
/*��ʼ�� ��*/
void initSnake(void)
{
	TCHAR str[100];
	for (int t = 0; t < 4; t++)
	{
		_stprintf(str, L".\\she\\head%d.bmp", t);
		loadimage(&imgHead[t], str);
	}
	loadimage(&imgBody, L".\\she\\body.bmp");
}
/*��ʾ�� */
void showSnake(void)
{
	putimage(snakeLie[0] * 30, snakeHang[0] * 30, &imgHead[fangXiang]);
	for (int i = 1;i < snakeSize;i++)
	{
		putimage(snakeLie[i] * 30, snakeHang[i] * 30, &imgBody);
	}
}